# Contributing

Before contributing, please read and follow all guidelines described on the documentation website: [https://diviyan-kalainathan.github.io/CausalDiscoveryToolbox/html/developer.html](https://diviyan-kalainathan.github.io/CausalDiscoveryToolbox/html/developer.html)

Thank you ! 
